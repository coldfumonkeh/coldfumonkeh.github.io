<?php
/**
Plugin Name: Scotch on the Rocks 2010 Badge
Plugin URI: http://www.mattgifford.co.uk/sotr-2010-wordpress-plugin/
Description: Places an badge for Scotch on the Rocks 2010 in the sidebar.
Author: Matt Gifford (AKA coldfumonkeh)
Version: 1.0
Author URI: http://www.mattgifford.co.uk/
*/

add_action( 'widgets_init', 'sotr_load_widgets' );

function sotr_load_widgets() {
	register_widget( 'SOTR2010_Widget' );
}

class SOTR2010_Widget extends WP_Widget {

	/**
	 * Widget setup.
	 */
	function SOTR2010_Widget() {
		/* Widget settings. */
		$widget_ops = array( 'classname' => 'badgeWidget', 'description' => __('A widget that adds an SOTR10 badge to the sidebar.', 'badgeWidget') );

		/* Widget control settings. */
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'sotrbadge-widget' );

		/* Create the widget. */
		$this->WP_Widget( 'sotrbadge-widget', __('SOTR 2010 Widget', 'badgeWidget'), $widget_ops, $control_ops );
	}

	/**
	 * How to display the widget on the screen.
	 */
	function widget( $args, $instance ) {
		extract( $args );

		/* Our variables from the widget settings. */
		$title = apply_filters('widget_title', $instance['title'] );
		$image = $instance['image'];
		$height = $instance['height'];
		$width = $instance['width'];

		/* Before widget (defined by themes). */
		echo $before_widget;

		/* Display the widget title if one was input (before and after defined by themes). */
		if ( $title )
			echo $before_title . $title . $after_title;

		/* Display name from widget settings if one was input. */
		
		$imgPath = WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),"",plugin_basename(__FILE__)); 
		
		$imgOutput = '<a href="http://www.scotch-on-the-rocks.co.uk/" title="Scotch on the Road 2010 - Europe\'s Longest Running ColdFusion Conference">';
		
		$imgOutput.= '<img src=" '.$imgPath.'badges/'.$image.'.png" height="'.$height.'" width="'.$width.'" />';
		$imgOutput.= '</a>';
		
		echo $imgOutput;
		

		/* After widget (defined by themes). */
		echo $after_widget;
	}

	/**
	 * Update the widget settings.
	 */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['image'] = strip_tags( $new_instance['image'] );

		/* No need to strip tags for sex and show_sex. */
		$instance['height'] = $new_instance['height'];
		$instance['width'] = $new_instance['width'];

		return $instance;
	}

	/**
	 * Displays the widget settings controls on the widget panel.
	 * Make use of the get_field_id() and get_field_name() function
	 * when creating your form elements. This handles the confusing stuff.
	 */
	function form( $instance ) {

		/* Set up some default widget settings. */
		$defaults = array( 'title' => 'SOTR 2010', 'image' => 'Attendee', 'height' => '125', 'width' => '250' );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- Widget Title: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'hybrid'); ?></label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
		</p>
		
		<!--- Image Select Box --->
		<p>
			<label for="<?php echo $this->get_field_id( 'image' ); ?>"><?php _e('Image:', 'badgeWidget'); ?></label> 
			<select id="<?php echo $this->get_field_id( 'image' ); ?>" name="<?php echo $this->get_field_name( 'image' ); ?>" class="widefat" style="width:100%;">
				<option <?php if ( 'Attendee' == $instance['image'] ) echo 'selected="selected"'; ?>>Attendee</option>
				<option <?php if ( 'Badger' == $instance['image'] ) echo 'selected="selected"'; ?>>Badger</option>
				<option <?php if ( 'Dates' == $instance['image'] ) echo 'selected="selected"'; ?>>Dates</option>
				<option <?php if ( 'Drinker' == $instance['image'] ) echo 'selected="selected"'; ?>>Drinker</option>
				<option <?php if ( 'Speaker' == $instance['image'] ) echo 'selected="selected"'; ?>>Speaker</option>
				<option <?php if ( 'Sponsor' == $instance['image'] ) echo 'selected="selected"'; ?>>Sponsor</option>
			</select>
		</p>
		
		<!-- Image Height: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'height' ); ?>"><?php _e('Image Height (default 125):', 'badgeWidget'); ?></label>
			<input id="<?php echo $this->get_field_id( 'height' ); ?>" name="<?php echo $this->get_field_name( 'height' ); ?>" value="<?php echo $instance['height']; ?>" style="width:75px;" />
		</p>
		
		<!-- Image Width: Text Input -->
		<p>
			<label for="<?php echo $this->get_field_id( 'width' ); ?>"><?php _e('Image Width (default 250):', 'badgeWidget'); ?></label>
			<input id="<?php echo $this->get_field_id( 'width' ); ?>" name="<?php echo $this->get_field_name( 'width' ); ?>" value="<?php echo $instance['width']; ?>" style="width:75px;" />
		</p>

	<?php
	}
}

?>